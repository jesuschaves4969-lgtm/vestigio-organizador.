# Vestigio Organizador (Android)

Proyecto Android inicial para clasificar fotos de catálogo por talla mediante OCR local de Google ML Kit.

## Funciones incluidas
- Selección múltiple de fotografías desde el selector de documentos Android.
- OCR en el dispositivo para detectar XS, S, M, L, XL, XXL y XXXL.
- Revisión manual de la talla detectada antes de organizar.
- Campo para indicar varias tallas separadas por coma, barra o punto y coma (ej. `S,M,L`).
- Creación de carpetas reales dentro de la carpeta elegida por el usuario, incluida `Talla por confirmar`.
- Copia a todas las tallas seleccionadas y solo intenta borrar el original después de que todas las copias de esa imagen hayan terminado correctamente. Si Android bloquea el borrado, conserva el original.

## Compilación desde GitHub
El flujo `.github/workflows/android.yml` compila automáticamente al subir el proyecto a la rama `main`, y también permite ejecutar manualmente `Compilar APK Vestigio` desde la pestaña Actions. El APK aparece como artefacto `Vestigio-APK`.

## Limitaciones de esta primera versión
- La detección OCR es una sugerencia y debe revisarse: puede confundir letras del diseño con tallas.
- El borrado del original depende de los permisos que conceda el proveedor de documentos de Android; si no lo permite, el original queda intacto.
- El APK generado por este flujo es de depuración, suficiente para instalar y probar; no es todavía una versión firmada para distribución pública.
