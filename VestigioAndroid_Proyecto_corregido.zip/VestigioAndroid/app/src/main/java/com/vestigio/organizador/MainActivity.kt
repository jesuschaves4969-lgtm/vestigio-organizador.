package com.vestigio.organizador

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.documentfile.provider.DocumentFile
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

class MainActivity : ComponentActivity() {
    data class Photo(val uri: Uri, val name: String, var sizes: MutableList<String> = mutableListOf(), var ocr: String = "")
    private val photos = mutableListOf<Photo>()
    private val sizes = listOf("XS", "S", "M", "L", "XL", "XXL", "XXXL", "Talla por confirmar")
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var chooseFolderButton: Button
    private var outputTree: Uri? = null

    private val pickPhotos = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        photos.clear()
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = queryName(uri)
            photos.add(Photo(uri, name))
        }
        status.text = "Leyendo tallas en ${photos.size} fotografías…"
        runOcr(0)
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            outputTree = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            chooseFolderButton.text = "Carpeta destino seleccionada ✓"
            status.text = "Destino listo. Revisa las tallas y pulsa Organizar."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 18); setBackgroundColor(Color.rgb(250,247,243)) }
        val title = TextView(this).apply { text = "VESTIGIO"; textSize = 27f; setTextColor(Color.rgb(75,54,43)); gravity = Gravity.CENTER; setTypeface(null, 1) }
        val subtitle = TextView(this).apply { text = "Organizador de fotografías por talla"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY); setPadding(0, 4, 0, 18) }
        val pick = Button(this).apply { text = "1. Seleccionar fotografías"; setOnClickListener { pickPhotos.launch(arrayOf("image/*")) } }
        chooseFolderButton = Button(this).apply { text = "2. Elegir carpeta destino"; setOnClickListener { pickFolder.launch(null) } }
        val organize = Button(this).apply { text = "3. Organizar fotografías"; setOnClickListener { organizePhotos() } }
        status = TextView(this).apply { text = "Selecciona las fotos del catálogo y revisa las tallas detectadas."; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0, 12, 0, 12) }
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(title); root.addView(subtitle); root.addView(pick); root.addView(chooseFolderButton); root.addView(organize); root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun queryName(uri: Uri): String {
        var name = "foto_${System.currentTimeMillis()}.jpg"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    private fun runOcr(index: Int) {
        if (index >= photos.size) { renderPhotos(); status.text = "Lectura terminada. Revisa o corrige cada talla antes de organizar."; return }
        val photo = photos[index]
        try {
            val image = InputImage.fromFilePath(this, photo.uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener { result ->
                    photo.ocr = result.text
                    photo.sizes = detectSizes(result.text).ifEmpty { mutableListOf("Talla por confirmar") }
                    runOcr(index + 1)
                }
                .addOnFailureListener {
                    photo.sizes = mutableListOf("Talla por confirmar")
                    runOcr(index + 1)
                }
        } catch (_: Exception) {
            photo.sizes = mutableListOf("Talla por confirmar")
            runOcr(index + 1)
        }
    }

    private fun detectSizes(text: String): MutableList<String> {
        val normalized = text.uppercase(Locale.ROOT).replace("×", "X").replace("3XL", "XXXL").replace("2XL", "XXL")
        val found = linkedSetOf<String>()
        val patterns = listOf("XXXL", "XXL", "XL", "XS", "S", "M", "L")
        val tokens = Regex("(?<![A-Z])(?:XXXL|XXL|XL|XS|S|M|L)(?![A-Z])")
        tokens.findAll(normalized).forEach { found.add(it.value) }
        // Common labels printed as TALLA: M / SIZE L are caught by token boundaries.
        return found.filter { it in patterns }.toMutableList()
    }

    private fun renderPhotos() {
        list.removeAllViews()
        photos.forEachIndexed { index, photo ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12); setBackgroundColor(Color.WHITE) }
            val name = TextView(this).apply { text = "${index + 1}. ${photo.name}"; textSize = 14f; setTextColor(Color.BLACK) }
            val detected = TextView(this).apply { text = if (photo.ocr.isBlank()) "No se pudo leer el texto" else "Texto leído: ${photo.ocr.take(160).replace('\n',' ')}"; textSize = 11f; setTextColor(Color.GRAY) }
            val choices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val spinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, sizes)
                setSelection(sizes.indexOf(photo.sizes.firstOrNull() ?: "Talla por confirmar").coerceAtLeast(0))
            }
            val multi = EditText(this).apply { hint = "Varias tallas: S,M,L"; textSize = 12f; setSingleLine(true); setText(photo.sizes.filter { it != "Talla por confirmar" }.joinToString(",")) }
            choices.addView(spinner, LinearLayout.LayoutParams(0, -2, 1f)); choices.addView(multi, LinearLayout.LayoutParams(0, -2, 1.4f))
            card.addView(name); card.addView(detected); card.addView(choices)
            card.tag = Pair(spinner, multi)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun organizePhotos() {
        val tree = outputTree?.let { DocumentFile.fromTreeUri(this, it) }
        if (tree == null || !tree.canWrite()) { status.text = "Primero selecciona una carpeta destino con permiso de escritura."; return }
        if (photos.isEmpty()) { status.text = "Primero selecciona fotografías."; return }
        var copied = 0; var failed = 0; var originalsRemoved = 0
        photos.forEachIndexed { index, photo ->
            val card = list.getChildAt(index) as? LinearLayout
            val controls = card?.tag as? Pair<*, *>
            val spinner = controls?.first as? Spinner
            val multi = controls?.second as? EditText
            val typed = multi?.text?.toString()?.uppercase(Locale.ROOT)?.split(',', '/', ';', ' ')
                ?.map { it.trim() }?.filter { it in sizes && it != "Talla por confirmar" }?.distinct().orEmpty()
            val selected = if (typed.isNotEmpty()) typed else listOf(spinner?.selectedItem?.toString() ?: "Talla por confirmar")
            var allCopiesOk = true
            selected.forEach { size ->
                try {
                    val folder = tree.findFile(size) ?: tree.createDirectory(size) ?: throw Exception("No se pudo crear carpeta $size")
                    val safeName = uniqueName(folder, photo.name)
                    val mime = contentResolver.getType(photo.uri) ?: "image/jpeg"
                    val dest = folder.createFile(mime, safeName) ?: throw Exception("No se pudo crear archivo")
                    contentResolver.openInputStream(photo.uri).use { input ->
                        if (input == null) throw Exception("No se pudo leer imagen")
                        contentResolver.openOutputStream(dest.uri, "w").use { output ->
                            if (output == null) throw Exception("No se pudo escribir imagen")
                            input.copyTo(output)
                        }
                    }
                    copied++
                } catch (_: Exception) { allCopiesOk = false; failed++ }
            }
            // Delete the source only after every requested destination copy succeeded.
            if (allCopiesOk) {
                try {
                    val rows = contentResolver.delete(photo.uri, null, null)
                    if (rows > 0) originalsRemoved++
                } catch (_: SecurityException) { /* Android may require explicit system approval; keep original safe. */ }
                catch (_: Exception) { /* Keep original if provider refuses deletion. */ }
            }
        }
        status.text = "Proceso terminado. Copias creadas: $copied. Errores: $failed. Originales eliminados: $originalsRemoved. Si Android no autorizó borrar algún original, permanece intacto."
    }

    private fun uniqueName(folder: DocumentFile, original: String): String {
        if (folder.findFile(original) == null) return original
        val dot = original.lastIndexOf('.')
        val base = if (dot > 0) original.substring(0, dot) else original
        val ext = if (dot > 0) original.substring(dot) else ""
        var n = 2
        while (folder.findFile("${base}_$n$ext") != null) n++
        return "${base}_$n$ext"
    }
}
